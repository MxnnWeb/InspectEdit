let isEditable = false;
const url = window.location.href;
let activeElement = null;

function saveContent(content) {
    let obj = {};
    obj[url] = content;
    chrome.storage.local.set(obj, () => {
        console.log('Content saved locally');
    });
}

function loadContent() {
    chrome.storage.local.get(url, (result) => {
        if(result[url]) {
            document.body.innerHTML = result[url];
            console.log('Content loaded from local storage');
        }
    });
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "toggleEdit") {
        isEditable = !isEditable;
        document.body.contentEditable = isEditable ? "true" : "false";
        if (!isEditable && activeElement) { 
            saveContent(document.body.innerHTML);
            activeElement.style.border = ""; 
            activeElement = null;
        }
    }
    
    if (request.action === "clearEdits") {
        chrome.storage.local.remove(url, function() {
            document.body.innerHTML = ''; 
            console.log('Edits cleared from local storage');
        });
    }
});

document.body.addEventListener('mouseover', function(e) {
    if (isEditable) {
        e.target.style.border = "2px solid blue"; 
    }
}, false);

document.body.addEventListener('mouseout', function(e) {
    if (isEditable && e.target !== activeElement) {
        e.target.style.border = ""; 
    }
}, false);

document.body.addEventListener('click', function(e) {
    if (isEditable) {
        if (activeElement) {
            activeElement.style.border = "";
        }
        activeElement = e.target;
        activeElement.style.border = "2px solid green"; 
        e.preventDefault();
    }
});

function debounce(func, wait, immediate) {
    var timeout;
    return function() {
        var context = this, args = arguments;
        clearTimeout(timeout);
        timeout = setTimeout(function() {
            timeout = null;
            if (!immediate) func.apply(context, args);
        }, wait);
        if (immediate && !timeout) func.apply(context, args);
    };
}

var saveChangesDebounced = debounce(function() {
    saveContent(document.body.innerHTML);
}, 5000);

document.body.addEventListener('input', function() {
    if (isEditable) {
        saveChangesDebounced();
    }
});

window.onload = loadContent;
